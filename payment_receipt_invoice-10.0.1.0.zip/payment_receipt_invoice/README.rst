Account Payment Receipt v10
===========================
This module will print detailed payment receipts.


Credits
=======
Cybrosys Techno Solutions
Author
------
* Cybrosys Techno Solutions<http://www.cybrosys.com>
